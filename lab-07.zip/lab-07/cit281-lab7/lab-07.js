//Logan Thompson

class CustomError extends Error {
    constructor (message) {
        super(message);
        this.genericError = "Generic Error"
        this.customError = "Custom Error"
    }
}

function throwGenericError(){
    throw new CustomError("Generic error");
}

function throwCustomError() {
    throw new CustomError("Custom error")
}

try {
    throwGenericError();
} catch (err) {
    console.log(`${err.message} catch block`);
    console.log(`Error: ${err.message}`);
} finally {
    console.log("Generic error finally block");
}

try {
    throwCustomError();
} catch (err) {
    console.log(`${err.message} catch block`);
    console.log(`Error: ${err.message}`);
} finally {
    console.log("Custom error finally block");
}

